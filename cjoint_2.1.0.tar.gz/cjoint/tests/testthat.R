library(testthat)
library(cjoint)

test_check("cjoint")
